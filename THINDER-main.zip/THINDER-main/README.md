# THINDER
Things Finder

This wireless-based tool uses Bluetooth as a transmitter and receiver to the Arduino nano which controls the buzzer component on or off which can be controlled by an application on the owner's smartphone. This tool has the ability to communicate with a distance of 10 meters.

Video: https://youtu.be/0KR1lQgHh80
